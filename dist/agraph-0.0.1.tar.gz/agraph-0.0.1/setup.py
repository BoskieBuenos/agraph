
from distutils.core import setup
setup(
    name = 'agraph',
    packages = ['agraph'],
    version = '0.0.1',
    license='TODO', # TODO
    description = 'ASCII graph definition utility',
    author = 'boskiebuenos',
    author_email = '', # TODO
    url = 'https://github.com/BoskieBuenos/agraph',
    download_url = 'https://github.com/BoskieBuenos/agraph/archive/v0.0.1.tar.gz', # TODO
    keywords = [''], # TODO
    install_requires=[],
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Testing',
        'License :: TODO', # TODO
        'Programming Language :: Python :: 3.7',
    ],
    python_requires='>=3.7',
)
