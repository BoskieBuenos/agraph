# TODO Rename to coordinates - singular form
class Point:
    def __init__(self, row: int, col: int):
        self.row: int = row
        self.col: int = col